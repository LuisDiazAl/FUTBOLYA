﻿namespace FutbolYa.WebAPI.Models
{
    public class MensajeDTO
    {
        public int PartidoId { get; set; }
       
        public string Contenido { get; set; }
    }
}
