﻿namespace FutbolYa.WebAPI.Models
{
    public class RendimientoDTO
    {
        public int PartidoId { get; set; }
        public int EvaluadoId { get; set; }
        public string Actitud { get; set; }
        public string Pase { get; set; }
        public string Defensa { get; set; }
        public string TrabajoEquipo { get; set; }
        public string Puntualidad { get; set; }
    }
}
